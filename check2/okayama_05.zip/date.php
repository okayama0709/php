<?php $fruits = array(
    'apple' => 'りんご',
    'orange' => 'みかん',
    'banana' => 'バナナ'
);
